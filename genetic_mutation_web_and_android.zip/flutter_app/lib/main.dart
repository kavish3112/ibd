import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

// Replace this with your deployed Render URL, e.g. https://your-service.onrender.com
const String apiBaseUrl = 'https://YOUR-RENDER-SERVICE.onrender.com';

void main() => runApp(const MutationApp());

class MutationApp extends StatelessWidget {
  const MutationApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'Genetic Mutation AI',
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF174A7E)), useMaterial3: true),
    home: const MutationHome(),
  );
}

class MutationHome extends StatefulWidget {
  const MutationHome({super.key});
  @override
  State<MutationHome> createState() => _MutationHomeState();
}

class _MutationHomeState extends State<MutationHome> {
  String gene = 'BRCA1';
  String status = 'Train a model before requesting a prediction.';
  String result = '';
  bool busy = false;
  final chromosome = TextEditingController(text: '17');
  final refLength = TextEditingController(text: '1');
  final altLength = TextEditingController(text: '1');
  final relativePos = TextEditingController(text: '0.5');
  final proteinPos = TextEditingController(text: '0');
  final cdnaPos = TextEditingController(text: '0');
  String variantType = 'single nucleotide variant';
  String consequence = 'missense_or_amino_acid_change';

  Future<void> train() async {
    setState(() { busy = true; status = 'Training may take several minutes while ClinVar data downloads…'; result = ''; });
    try {
      final response = await http.post(Uri.parse('$apiBaseUrl/api/train'),
        headers: {'Content-Type': 'application/json'}, body: jsonEncode({'gene': gene}));
      final data = jsonDecode(response.body);
      if (response.statusCode >= 300) throw Exception(data['error'] ?? 'Training failed');
      setState(() => status = '${data['message']}\nCounts: ${data['counts']}\nMetrics: ${data['metrics']}');
    } catch (e) {
      setState(() => status = 'Could not train: $e\nCheck apiBaseUrl and the deployed server.');
    } finally { setState(() => busy = false); }
  }

  Future<void> predict() async {
    setState(() { busy = true; result = ''; });
    try {
      final body = {
        'chromosome': chromosome.text, 'variant_type': variantType, 'consequence_group': consequence,
        'ref_length': double.parse(refLength.text), 'alt_length': double.parse(altLength.text),
        'relative_gene_position': double.parse(relativePos.text),
        'protein_position': double.parse(proteinPos.text), 'cdna_position': double.parse(cdnaPos.text),
      };
      final response = await http.post(Uri.parse('$apiBaseUrl/api/predict'),
        headers: {'Content-Type': 'application/json'}, body: jsonEncode(body));
      final data = jsonDecode(response.body);
      if (response.statusCode >= 300) throw Exception(data['error'] ?? 'Prediction failed');
      setState(() => result = 'Gene: ${data['gene']}\nPrediction: ${data['prediction']}\nScores: ${data['model_scores']}\n\n${data['notice']}');
    } catch (e) { setState(() => result = 'Prediction failed: $e'); }
    finally { setState(() => busy = false); }
  }

  Widget field(String label, TextEditingController c, {bool decimal = false}) => Padding(
    padding: const EdgeInsets.only(bottom: 10),
    child: TextField(controller: c, keyboardType: const TextInputType.numberWithOptions(decimal: true),
      decoration: InputDecoration(labelText: label, border: const OutlineInputBorder())),
  );

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Genetic Mutation AI')),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      const Text('AI-Based Prioritization of Genetic Mutations', style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      const Text('Educational prototype only. Not for clinical or medical decision-making.'),
      const SizedBox(height: 18),
      DropdownButtonFormField<String>(value: gene, decoration: const InputDecoration(labelText: 'Gene', border: OutlineInputBorder()),
        items: ['BRCA1','TP53','CFTR','APC','MTHFR','PMM2'].map((g) => DropdownMenuItem(value: g, child: Text(g))).toList(),
        onChanged: busy ? null : (v) { if (v != null) setState(() => gene = v); }),
      const SizedBox(height: 10),
      FilledButton(onPressed: busy ? null : train, child: const Text('Load ClinVar and train')),
      const SizedBox(height: 10),
      SelectableText(status),
      const Divider(height: 32),
      const Text('Demonstration prediction', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
      const SizedBox(height: 10),
      field('Chromosome', chromosome),
      DropdownButtonFormField<String>(value: variantType, decoration: const InputDecoration(labelText: 'Variant type', border: OutlineInputBorder()),
        items: ['single nucleotide variant','Deletion','Insertion','Duplication','Unknown'].map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(),
        onChanged: busy ? null : (v) { if (v != null) setState(() => variantType = v); }),
      const SizedBox(height: 10),
      DropdownButtonFormField<String>(value: consequence, decoration: const InputDecoration(labelText: 'Estimated consequence', border: OutlineInputBorder()),
        items: ['missense_or_amino_acid_change','frameshift','stop_gained','splice_related','synonymous_or_no_protein_change','deletion','duplication','insertion','other_or_unknown'].map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(),
        onChanged: busy ? null : (v) { if (v != null) setState(() => consequence = v); }),
      const SizedBox(height: 10),
      field('Reference allele length', refLength),
      field('Alternate allele length', altLength),
      field('Relative gene position (0–1)', relativePos),
      field('Protein position (0 if unknown)', proteinPos),
      field('cDNA position (0 if unknown)', cdnaPos),
      FilledButton(onPressed: busy ? null : predict, child: const Text('Predict category')),
      if (busy) const Padding(padding: EdgeInsets.all(12), child: Center(child: CircularProgressIndicator())),
      if (result.isNotEmpty) Card(child: Padding(padding: const EdgeInsets.all(12), child: SelectableText(result))),
    ]),
  );
}
